# Instructions  

1. Refactor the code to use .map() instead of 
   the for-loop.
2. Don't worry about the commas for now.